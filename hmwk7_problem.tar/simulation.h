#ifndef SIMULATION
#define SIMULATION

void simulation(double spec_prob, double *time, double *radius);

#endif
